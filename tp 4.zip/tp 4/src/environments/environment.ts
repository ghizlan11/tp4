export const environment = {
    apiLink : 'https://reqres.in/api'
};
