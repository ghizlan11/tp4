import { Routes } from '@angular/router';
import { HomeComponent } from './elements/pages/home/home.component';
import { UsersListComponent } from './elements/pages/users/list/users-list.component';
import { UpdateComponent } from './elements/pages/users/update/update.component';

export const routes: Routes = [
    {path :"",component:HomeComponent},
    {path :"users",component:UsersListComponent},
    {path :"users/update/:id",component:UpdateComponent},
];
