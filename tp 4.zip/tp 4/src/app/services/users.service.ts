import { Injectable } from '@angular/core';
import { User } from '../types/User.type';
import { BehaviorSubject, Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  private _users:User[] = [];
  private usersSubject: BehaviorSubject<User[]> = new BehaviorSubject<User[]>(this._users);

  constructor() { }

  getUsers = (): Observable<Array<User>> => {
    return this.usersSubject.asObservable();
  }

  getUser = (id:number) : User | null =>{
    let user = this._users.find(e => e.id === id);
    if (user) {
      return user;
    }
    return null;
  }

  getNewUser = () : User =>{
    let length = this._users.length +1;
    let user : User ={
      id:length,
      avatar : '',
      firstname : '',
      lastname : '',
      email : ''
    }
    return user;
  }

  saveUser = (user:User) =>{
    let org = this.getUser(user.id);
    if (org) {
      let index = this._users.indexOf(org);
      this._users[index] = user;
      this.usersSubject.next(this._users);
    }else{
      this._users.push(user);
      this.usersSubject.next(this._users);
    }
  }

  removeUser = (id:number) =>{
      let org = this.getUser(id);
      if (org) {
        this._users = this._users.filter((e) => e.id !== id);
        this.usersSubject.next(this._users);
      }
  }
}
