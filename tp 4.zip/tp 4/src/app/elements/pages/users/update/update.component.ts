import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UsersService } from '../../../../services/users.service';
import { User } from '../../../../types/User.type';
import { Route, Router,ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-update',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './update.component.html',
  styleUrl: './update.component.scss'
})
export class UpdateComponent implements OnInit  {

  user !: User; 
  title : string = "Update User";

  constructor (private activeroute:ActivatedRoute,
    private router:Router,
    private usersService:UsersService) {
  }

  ngOnInit(): void {
   const id = +this.activeroute.snapshot.paramMap.get('id')!;

   if (!isNaN(id)) {
     this.user = this.usersService.getUser(id)!;
     if (this.user) {
       return;
     }
     this.title = "New User";
     this.user = this.usersService.getNewUser();
   }
  }

  Save = (): void =>{
    this.usersService.saveUser(this.user);
    this.goback();
  }

  goback = () =>{
    this.router.navigateByUrl('/users');
  }

}
