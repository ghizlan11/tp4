import { Component } from '@angular/core';
import { UsersService } from '../../../../services/users.service';
import { User } from '../../../../types/User.type';
import { Subscription } from 'rxjs';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-users-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './users-list.component.html',
  styleUrl: './users-list.component.scss'
})
export class UsersListComponent {

  Users: User[] = [];
  usersSub!: Subscription;

  constructor (private router: Router,private usersService: UsersService) {}

  ngOnInit(): void {
    this.usersSub = this.usersService
      .getUsers()
      .subscribe((users) => {
        this.Users = users;
      });
  }

  redirecToUpdatePage = (id :number) =>{
    this.router.navigate(['users/update',id]);
  }

  redirecToCreatePage = () =>{
    this.router.navigate(['users/update',0]);
  }

  removeUser =(id:number) =>{
    this.usersService.removeUser(id);
  }

  handleSelectChange(event: any, user: User) {
    const selectedValue = event.target.value;
    console.log('done');
    if (selectedValue === '1') {
      this.redirecToUpdatePage(user.id);
    } else if (selectedValue === '2') {
      this.removeUser(user.id);
    }
  }
  

  ngOnDestroy(): void {
    this.usersSub.unsubscribe();
  }
}
